<template>
  <div>
    <v-text-field
      v-model="search"
      density="compact"
      placeholder="Поиск по нику"
      prepend-inner-icon="mdi-magnify"
      class="mb-2"
      hide-details
    />

    <v-list lines="one">
      <ChatItem
        v-for="chat in displayedChats"
        :key="chat._id"
        :chat="chat"
        :user-id="userId"
        @selectChat="$emit('selectChat', $event)"
      />
    </v-list>
  </div>
</template>

<script setup lang="ts">
import { ref, watch, computed, onMounted } from "vue";
import ChatItem from "./ChatItem.vue";
import type { Chat } from "@/types/chat";
import { useChatStore } from "@/stores/chat";

const { $chatApi } = useNuxtApp();
const emit = defineEmits(["selectChat"]);

const userId = 4; // TODO: заменить на authStore
const search = ref("");
const searchResults = ref<Chat[]>([]);
const chatStore = useChatStore();

onMounted(() => {
  if (process.client) {
    chatStore.fetchChats();
  }
});

watch(search, async (value) => {
  if (value.length >= 2) {
    try {
      const res = await $chatApi.get("/users/search", {
        params: { query: value },
        headers: {
          Authorization: `Bearer ${localStorage.getItem("token")}`
        }
      });
      searchResults.value = res.data.map((user: any) => ({
        _id: user.id,
        members: [{ username: user.username, avatar_url: user.avatar_url }]
      }));
    } catch (e) {
      console.error("Ошибка поиска:", e);
      searchResults.value = [];
    }
  } else {
    searchResults.value = [];
  }
});

// 👇 Показываем либо searchResults, либо чаты
const displayedChats = computed(() => {
  return search.value.length >= 2 ? searchResults.value : chatStore.chats;
});
</script>

import { defineStore } from 'pinia'
import { ref } from 'vue'
import type { Chat, Message } from '@/types/chat'

export const useChatStore = defineStore('chat', () => {
  const chats = ref<Chat[]>([])
  const messages = ref<Message[]>([])
  const activeChatId = ref<string | null>(null)

  const fetchChats = async () => {
    try {
      const token = localStorage.getItem('token') || ''
      const { $chatApi } = useNuxtApp()

      const res = await $chatApi.get('/chats', {
        headers: {
          Authorization: `Bearer ${token}`
        }
      })

      chats.value = res.data || []
    } catch (error) {
      console.error('Ошибка загрузки чатов:', error)
    }
  }

  const fetchMessages = async (chatId: string) => {
    try {
      const token = localStorage.getItem('token') || ''
      const { $chatApi } = useNuxtApp()

      const res = await $chatApi.get(`/chats/${chatId}/messages`, {
        headers: {
          Authorization: `Bearer ${token}`
        }
      })

      messages.value = res.data || []
      activeChatId.value = chatId
    } catch (error) {
      console.error('Ошибка загрузки сообщений:', error)
    }
  }

  const sendMessage = async (content: string) => {
    if (!activeChatId.value) return
    try {
      const token = localStorage.getItem('token') || ''
      const { $chatApi } = useNuxtApp()

      const res = await $chatApi.post('/messages', {
        chat_id: activeChatId.value,
        content
      }, {
        headers: {
          Authorization: `Bearer ${token}`
        }
      })

      if (res.data) {
        messages.value.push(res.data as Message)
      }
    } catch (error) {
      console.error('Ошибка отправки сообщения:', error)
    }
  }

  return {
    chats,
    messages,
    activeChatId,
    fetchChats,
    fetchMessages,
    sendMessage
  }
})

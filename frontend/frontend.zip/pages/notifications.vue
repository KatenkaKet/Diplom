<template><h1>Заглушка: {{ $route.path }}</h1></template>

<template>
  <v-container>
    <!-- Поиск и фильтр -->
    <div class="d-flex align-center mb-6">
      <v-btn icon class="mr-2" color="#990000">
        <v-icon>mdi-filter-variant</v-icon>
      </v-btn>
      <v-text-field
        v-model="search"
        placeholder="Поиск..."
        rounded
        hide-details
        clearable
        prepend-inner-icon="mdi-magnify"
        class="search-field"
        :style="{ backgroundColor: '#990000', color: 'white' }"
      />
    </div>

    <!-- Популярные -->
    <h2 class="mb-2 section-title">Популярные ➝</h2>
    <v-slide-group show-arrows class="d-flex ga-4">
      <v-slide-item v-for="course in popularCourses" :key="course.ID">
        <CourseCard :course="course" />
      </v-slide-item>
    </v-slide-group>

    <!-- Для начинающих -->
    <h2 class="mt-8 mb-2 section-title">Для начинающих ➝</h2>
    <v-slide-group show-arrows class="d-flex ga-4">
      <v-slide-item v-for="course in beginnerCourses" :key="course.ID">
        <CourseCard :course="course" />
      </v-slide-item>
    </v-slide-group>
  </v-container>
</template>

<script setup lang="ts">
import { ref } from 'vue'

const search = ref('')

const popularCourses = [
  {
    ID: 1,
    Title: 'Маркетинг',
    School: 'Redford School',
    ImageURL: '',
  },
  { ID: 2, Title: 'Frontend', School: 'Redford School', ImageURL: '' },
  { ID: 3, Title: 'Продажи', School: 'Redford School', ImageURL: '' },
]

const beginnerCourses = [
  { ID: 4, Title: 'Основы бизнеса', School: 'Redford School', ImageURL: '' },
  { ID: 5, Title: 'Психология', School: 'Redford School', ImageURL: '' },
  { ID: 6, Title: 'Работа с клиентами', School: 'Redford School', ImageURL: '' },
]
</script>

<style scoped>
.section-title {
  font-size: 20px;
  font-weight: 600;
  color: #990000;
}

.search-field {
  flex: 1;
  border-radius: 999px;
}
</style>

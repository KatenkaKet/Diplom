<template>
  <v-container class="pa-6">
    <v-card>
      <v-card-title class="text-h5">Проверка Vuetify</v-card-title>
      <v-card-text>
        Если ты видишь эту карточку — Vuetify работает! 🎉
      </v-card-text>
      <v-card-actions>
        <v-btn color="primary">Нажми меня</v-btn>
      </v-card-actions>
    </v-card>
  </v-container>
</template>
